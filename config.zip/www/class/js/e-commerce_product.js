$('.bxslider').bxSlider({
      pagerCustom: '#bx-pager'
});
